package es.ua.iweb.paqueteria.type;

public enum EstadoType {
    ACEPTADO,
    ENTREGADO,
    PENDIENTE,
    EN_RUTA,
    AUSENTE,
    RECHAZADO
}
