package es.ua.iweb.paqueteria.type;

public enum TokenType {
    BEARER
}
