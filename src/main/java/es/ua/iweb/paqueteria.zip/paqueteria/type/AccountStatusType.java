package es.ua.iweb.paqueteria.type;

public enum AccountStatusType {
    VERIFIED,
    NOT_VERIFIED,
    SUSPENDED,
    DELETED
}
