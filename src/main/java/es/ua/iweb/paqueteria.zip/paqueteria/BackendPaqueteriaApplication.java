package es.ua.iweb.paqueteria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendPaqueteriaApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendPaqueteriaApplication.class, args);
    }

}
