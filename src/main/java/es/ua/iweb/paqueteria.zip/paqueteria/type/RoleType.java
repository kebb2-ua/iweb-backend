package es.ua.iweb.paqueteria.type;

public enum RoleType {
    USER,
    ADMIN
}
